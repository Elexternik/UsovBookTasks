var array = Array(1...4)
var summOfLastAndFirst = array[0] + array[3]
var a: Int = Int(array.last!) + Int(array.first!)
array[1...2] = [a]
/* Также можно воспользоваться другим методом
array[1...2] = [summOfLastAndFirst]
*/
array.sorted()

